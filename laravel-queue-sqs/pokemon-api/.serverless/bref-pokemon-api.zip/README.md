# Proyek 1 - Pokemon API

1. Hapus komentar dari `$app->withFacades` di `bootstrap/app.php`
2. Simpan `file` **pokemon.csv** di `storage/app`
3. Install package Flysystem: `composer require league/flysystem`
4. Jalankan proyek: `php -S localhost:8000 -t public`
5. Buka URL -> `http://localhost:8000/pokemon`